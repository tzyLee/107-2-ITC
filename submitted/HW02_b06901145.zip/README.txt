Python version: Python 3.7.1 (CPython)
Execution:
    python hw2.py

I finished the bonus part.

    Usage: (Use Simulator.loadAssembly to load assembly text files, pass in the path of the file)
        sim = Simulator.Simulator()
        sim.loadAssembly("input/bonus.txt")
        sim.simulate()
        sim.storeMemory("output/bonus")
