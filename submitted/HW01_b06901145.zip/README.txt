Compile:

    g++ -std=c++11 main.cpp

    - Tested on g++ (Ubuntu 7.3.0-27ubuntu1~18.04) 7.3.0
or alternatively

    clang++ -std=c++11 main.cpp
    
    - Tested on clang version 5.0.0 
                Target: x86_64-unknown-linux-gnu
                Thread model: posix

Bonus:

    I finished the bonus part.

    Using Y = (30*R + 59*G + 11*B)/100, the average error is 0.3839,
    Using Y = (299*R + 587*G + 114*B)/1000, the average error is 0.00322083

    Compared with cv2 on python
