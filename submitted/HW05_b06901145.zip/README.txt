Compiler:
    g++ (Ubuntu 7.4.0-1ubuntu1~18.04) 7.4.0

Compile:
    g++ -std=c++11 testHeap.cpp
    g++ -std=c++11 bonus.cpp

I finished the bonus part.