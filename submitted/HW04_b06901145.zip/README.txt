Compiler:
    g++ (Ubuntu 7.4.0-1ubuntu1~18.04) 7.4.0

Compile:
    g++ bonus.cpp -std=c++11
    g++ hw4.cpp -std=c++11

I finished the bonus part.