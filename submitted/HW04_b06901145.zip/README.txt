Compiler:
    g++ (Ubuntu 7.4.0-1ubuntu1~18.04) 7.4.0

I finished the bonus part.